import urllib, httplib
import json

data = {'name' : 'base-FAN 1L', 'direction' : 'f2b', 'rpm': 9450,'speed': 'normal', 'status' : 'ok' } 
headers = {"Content-type": "application/json", "Accept": "text/plain"}
#conn = httplib.HTTPConnection("10.10.10.2", 8091, json.dumps(data), headers)
conn = httplib.HTTPConnection("10.10.10.2", 8091)
conn.request("GET", "/system",json.dumps(None), headers)
response = conn.getresponse()
print response.status, response.reason
print response.read()
conn.close()

