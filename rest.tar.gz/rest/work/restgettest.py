import RestService
import pprint

rest_handle = RestService.RestService(switch_ip="10.10.10.2")
result = rest_handle.getResponse('/system')
print result[0]
pprint.pprint(result[1])
