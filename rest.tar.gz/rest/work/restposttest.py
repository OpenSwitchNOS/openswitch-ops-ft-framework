import RestService
import pprint
data = {'name' : 'base-FAN 1L', 'direction' : 'f2b', 'rpm': 9450,'speed': 'normal', 'status' : 'ok' }
rest_handle = RestService.RestService(switch_ip="10.10.10.2")
result = rest_handle.postResponse('/system/susbsystems/base/fans', data)
print result[0]
pprint.pprint(result[1])
