import urllib, httplib
import json

data = {'name' : 'base-FAN 1L', 'direction' : 'f2b', 'rpm': 9450,'speed': 'normal', 'status' : 'ok' } 
headers = {"Content-type": "application/json", "Accept": "text/plain"}
conn = httplib.HTTPConnection("10.10.10.2", 8091)
conn.request("POST", "/system/susbsystems/base/fans",
        json.dumps(data), headers)
response = conn.getresponse()
print response.status, response.reason
print response.read()
conn.close()
